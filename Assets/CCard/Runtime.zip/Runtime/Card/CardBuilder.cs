﻿namespace Cf.CCard
{
    public class CardBuilder : ICardBuilder
    {
        public CardBuilder(CardData data)
        {
            
        }

        public ICard Build()
        {
            throw new System.NotImplementedException();
        }
    }
}