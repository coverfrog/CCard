using UnityEngine;

namespace Cf.CCard
{
    [CreateAssetMenu(menuName = "Cf/CCard/Card/Data", fileName = "CardData")]
    public class CardData : ScriptableObject
    {
        
    }
}
