﻿namespace Cf.CCard
{
    public interface ICard
    {
        
    }
}