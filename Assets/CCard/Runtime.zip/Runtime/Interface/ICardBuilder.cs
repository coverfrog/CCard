﻿namespace Cf.CCard
{
    public interface ICardBuilder
    {
        ICard Build();
        
        
    }
}