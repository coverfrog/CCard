﻿namespace Cf.CCard
{
    public interface ICardStack
    {
        Card Stack();
    }
}